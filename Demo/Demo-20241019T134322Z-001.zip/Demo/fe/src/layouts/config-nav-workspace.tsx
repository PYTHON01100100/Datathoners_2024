// ----------------------------------------------------------------------

export const _workspaces = [
  {
    id: 'team-1',
    name: 'Dathoners',
    logo: `/assets/icons/workspaces/logo-1.webp`,
    plan: '👋',
  },
];
